# Atalaia

Monitoramento de segurança leve para VPS e servidores de pequenas e médias empresas.

O Atalaia junta a ideia do Wazuh (regras de host, integridade de arquivos, MITRE ATT&CK) com a do Security Onion (visão de rede e caça a ameaças) em um agente que cabe em uma VPS de 1 GB de RAM, sem Elasticsearch, sem Java, sem dependências externas.

| | Wazuh | Security Onion | Atalaia |
|---|---|---|---|
| RAM mínima recomendada | 4 GB ou mais (servidor + indexador) | 12 GB ou mais | 30 MB |
| Instalação | Horas | Máquina dedicada | 1 comando |
| Dependências | Muitas | Distribuição inteira | Só Python 3.9+ |
| Relatório em português para o dono da empresa | Não | Não | Sim, com IA |
| Alerta no WhatsApp | Via integração | Via integração | Nativo |

## O que ele detecta

Cada evento é classificado como `normal`, `suspeito` ou `critico`. Eventos normais viram apenas contadores (não ocupam disco); só o que é suspeito é gravado.

| Área | Exemplos de detecção |
|---|---|
| SSH | força bruta, enumeração de usuários, login como root, **login com sucesso depois de força bruta**, login de origem nunca vista |
| Sistema | criação de usuário, entrada em grupo sudo ou docker, sudo com comandos de pós exploração, falhas de sudo |
| Web (nginx, apache, traefik) | busca por `.env` e `.git`, SQL injection, Log4Shell, path traversal, varredura de diretórios, força bruta em painel, scanners conhecidos, **arquivo sensível exposto com status 200** |
| Rede | varredura de portas (logs do UFW ou iptables), nova porta aberta para a internet |
| Integridade (FIM) | alteração em `authorized_keys`, `passwd`, `shadow`, `sudoers`, cron, serviços systemd, `ld.so.preload` |

São 23 regras iniciais, todas mapeadas para técnicas do MITRE ATT&CK. Veja com `atalaia rules`.

### Como ele evita o excesso de falso positivo

1. **Período de aprendizado:** nas primeiras 24 horas as regras do tipo "nunca visto" só aprendem, não alertam.
2. **Agrupamento:** um scanner que dispara 500 vezes gera 1 alerta com contador 500, e não 500 mensagens.
3. **Limite de notificação:** no máximo 10 mensagens a cada 5 minutos por servidor.
4. **Ajuste por cliente:** `whitelist_ips` aceita IPs e faixas (`192.168.0.0/24`), `rules_disabled` desliga regras e `rules_override` muda severidade ou limites sem mexer no código.

## Agente de IA

Com a IA ativada, o Atalaia:

1. Gera todo dia um **relatório em linguagem de dono de empresa**: resumo executivo, nível de risco, incidentes, prováveis falsos positivos e até 5 sugestões com o comando exato.
2. **Explica alertas críticos na hora**, junto com a notificação.

A IA nunca recebe logs brutos, apenas o resumo agregado do dia. Sem IA o relatório continua sendo gerado, em formato objetivo. O produto nunca depende de um serviço externo para funcionar.

## Instalação

```bash
git clone https://github.com/Odiveighar/atalaia.git
cd atalaia
sudo bash deploy/install.sh
```

O instalador copia para `/opt/atalaia`, cria `/etc/atalaia/config.json`, registra o serviço no systemd com limite de 96 MB de RAM e 20% de CPU, e já inicia o monitoramento.

Para ativar a IA, coloque a chave em `/etc/atalaia/env`, mude `"enabled": true` na seção `ai` e reinicie:

```bash
sudo nano /etc/atalaia/env
sudo nano /etc/atalaia/config.json
sudo systemctl restart atalaia
```

### Traefik em Docker

O Traefik escreve o access log no stdout por padrão. Para o Atalaia ler, ative o arquivo:

```yaml
command:
  - "--accesslog=true"
  - "--accesslog.filepath=/var/log/traefik/access.log"
volumes:
  - /var/log/traefik:/var/log/traefik
```

## Comandos

```bash
atalaia check          # valida configuracao, fontes de log e chave da IA
atalaia status         # resumo das ultimas 24 horas
atalaia alerts --min alta --hours 48
atalaia report         # gera o relatorio agora (--send envia nos canais)
atalaia rules          # lista regras e se estao ativas
atalaia test-notify    # testa Telegram, WhatsApp e webhook
```

### Diagnóstico offline (ferramenta de venda)

Analisa logs de qualquer servidor **sem instalar nada nele**. Peça ao cliente os arquivos e rode no seu computador:

```bash
python3 -m atalaia analyze auth:auth.log http:access.log firewall:ufw.log --report
```

Teste agora com os logs de exemplo, que simulam uma invasão completa:

```bash
python3 -m atalaia analyze auth:samples/auth.log http:samples/access.log firewall:samples/ufw.log --report
```

## Notificações

Configure na seção `notify`. Pode usar mais de um canal ao mesmo tempo.

| Canal | Campos |
|---|---|
| Telegram | `bot_token`, `chat_id` |
| WhatsApp (Evolution API) | `url`, `instance`, `apikey`, `number` |
| Webhook | `url` (recebe JSON com o alerta completo) |

## Consumo medido

Teste com 200 mil linhas de log HTTP em um único núcleo:

| Métrica | Resultado |
|---|---|
| Vazão | cerca de 28 mil linhas por segundo |
| Pico de RAM | 23 MB |
| RAM em operação contínua | 25 a 30 MB |
| Banco de dados após o teste | 60 KB |

## Criando regras

Crie um arquivo JSON e aponte em `rules_extra`. Tipos disponíveis:

| Tipo | Quando dispara |
|---|---|
| `match` | o evento bate com as condições |
| `threshold` | `count` eventos do mesmo grupo dentro de `window` segundos |
| `distinct` | o mesmo grupo gera `count` valores diferentes do campo `distinct` |
| `new_value` | a combinação dos campos `keys` aparece pela primeira vez |
| `sequence` | a regra em `requires.rule` já disparou para a mesma chave |

Exemplo, alertar todo acesso bem sucedido ao painel administrativo:

```json
[
  {
    "id": "CLI-001",
    "title": "Acesso ao painel administrativo",
    "kind": "match",
    "severity": "media",
    "mitre": "T1078",
    "match": {"etype": "http", "path": "^/admin", "status": "^200$"},
    "group_by": "ip",
    "recommendation": "Confirmar se o acesso foi feito por alguem da equipe."
  }
]
```

## Estrutura

```
atalaia/
  agent.py        loop principal
  collectors.py   leitura de logs, integridade de arquivos, portas
  parsers.py      normalizacao de logs
  engine.py       motor de regras e classificacao
  rules/          regras padrao com MITRE ATT&CK
  storage.py      SQLite
  report.py       relatorio diario
  ai.py           agente de IA
  notify.py       Telegram, WhatsApp, webhook
deploy/           instalador e servico systemd
samples/          logs de exemplo para demonstracao
tests/            testes automatizados
docs/             plano de produto e roadmap
```

## Testes

```bash
python3 -m unittest discover -s tests -v
```

## Limitações conhecidas do MVP

1. A parte de rede é leve: usa logs do firewall e as portas abertas. Não inspeciona pacotes como o Suricata.
2. Linhas escritas no arquivo antigo no exato momento da rotação de log podem ser perdidas.
3. Ainda não lê o journald diretamente. Em sistemas sem rsyslog, instale com `apt install rsyslog`.
4. Monitora um servidor por instalação. O painel central para vários clientes está no roadmap.
